=== news announcement scroll ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/
Tags: news, announcement, scroll news
Author URI: http://www.gopiplus.com/
Plugin URI: http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/
Requires at least: 3.0
Tested up to: 3.5
Stable tag: 6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
This plug-in will create a vertical scroll news or Announcement for your word press site, we can embed this in site sidebar.

== Description ==

Check official website for Live demo and Video tutorial [http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)

*   [Live Demo](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)		
*   [Video tutorial](http://www.gopiplus.com/work/plugin-list/)	
*   [More Information](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)	
*   [Download link](http://www.gopiplus.com/work/wordpress-plugin-download/)	

News announcement scroll wordpress plug-in create a vertical scroll news widget for your wordpress website, This is same as announcement and vertical scroll news wordpress plugin. announcement and vertical scroll news wordpress plugin disappeared suddenly from wordpress directory, so i have created the same plugin with different name. This is very easy to use, no coding knowledge required to customize this plugin. after activated the plugin, drag and drop the widget into the sidebar.	

1. Easy installation.  
2. Widgets, so you can add pretty much anything.  
3. Easy style-override system.  
4. Expiration date setup.  
5. You can add N number of news; it will scroll one by one at front end (vertical scrolling).   
6. You can arrange the scrolling news order. Also you can customize the scroll direction.  
7. If you want, you can hide the news temporarily.   
8. Only ADMIN user can access this plug-in.
9. Short code availabe for pages and posts.

**Plugin configuration**

Option 1. Drag and Drop the widget.

Option 2. Add the announcement in the posts or pages using short code.

Option 3. Add directly in to the theme using php code.

[Plugin configuration](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)

== Installation ==

**Installation Instruction**

[Installation Instruction](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)		
  
**To configure**

[Plugin configuration](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)	

== Frequently Asked Questions == 

**Can I display more news at same time?**  
  
**Can I change the scroll manner from vertical to horizontal?**  
  
**Can I display announcement in random order?**  
	
**Can I arrange the news scroll order?**  
  
**Can I hide the any news temporary?**  
  
**Can I set expiration for announcement?**  

**Can I change the Slide Direction?**  
  
**Can I customize the all other appearance style?**  

**Why my news content out of range?**  

**How to type other then English?**  

**How to add this scrolling into pages or posts?** 

**How to add different set of scroll in the same page?** 


[Frequently Asked Questions & Answers](http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/)

== Upgrade Notice ==

= 1.0 = 		
First version

= 2.0 = 		
Short code available for posts and pages.

= 3.0 = 		
Tested UpTo 3.3
Javascript included as per WP standard.

= 4.0 = 		
Tested UpTo 3.4

= 5.0 =
New demo link, www.gopiplus.com

= 6.0 =
Tested UpTo 3.5

== Screenshots ==

1. http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/ 	
2. http://www.gopiplus.com/work/2011/01/01/news-announcement-scroll/ 	

== Changelog ==

= 1.0 = 		
First version.

= 2.0 = 		
Short code available  for posts and pages.

= 3.0 = 		
Tested UpTo 3.3
Javascript included as per WP standard.

= 4.0 = 		
Tested UpTo 3.4

= 5.0 =
New demo link, www.gopiplus.com

= 6.0 =
Tested UpTo 3.5