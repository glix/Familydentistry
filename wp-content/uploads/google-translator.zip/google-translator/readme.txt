=== Google Translator ===
Contributors: V.J.Catkick
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2933164
Tags: google, translator, sidebar
Requires at least: 2.5
Tested up to: 2.7
Stable tag: 4.3

Google Translate on your sidebar. You can translate your blog to reader's language from sidebar instantly by selecting language.

== Description ==

Google translation on your sidebar. By adding this widget, the readers are easily to change your language to their languages by just selecting pull down menu. Base language selectable, multi language supported.

== Installation ==

Place file in your /wp-content/plugins/ directory
and activate through the administration panel, and then go to the widget panel and
drag it to where you would like to have it!

== Frequently Asked Questions ==

= Mom, I don't understand! =

Remember, this is  'machine' translation therefore only 'proper' language will be translated. (Maybe this is good time to start using good language? nooooot!)

== Screenshots ==

1. Main View
2. Option Panel

