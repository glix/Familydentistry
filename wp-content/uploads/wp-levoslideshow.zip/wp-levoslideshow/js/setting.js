jQuery(function($)
{
jQuery('#color_picker_color1').farbtastic("#settings\\[controls_color\\]");
jQuery('#color_picker_color2').farbtastic("#settings\\[description_color\\]");
jQuery('#color_picker_color3').farbtastic("#settings\\[desc_bg_color1\\]");
jQuery('#color_picker_color4').farbtastic("#settings\\[desc_bg_color2\\]");
jQuery('#color_picker_color5').farbtastic("#settings\\[bg_color1\\]");
jQuery('#color_picker_color6').farbtastic("#settings\\[bg_color2\\]");
jQuery('#color_picker_color7').farbtastic("#settings\\[thumbs_bar_color\\]");
jQuery('#color_picker_color8').farbtastic("#settings\\[menu_button_bg_color\\]");
jQuery('#color_picker_color9').farbtastic("#settings\\[menu_up_color\\]");
jQuery('#color_picker_color10').farbtastic("#settings\\[menu_over_color\\]");
jQuery('#color_picker_color11').farbtastic("#settings\\[price_color\\]");
jQuery('#color_picker_color12').farbtastic("#settings\\[currency_color\\]");




});
