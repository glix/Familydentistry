jQuery(document).ready(function() {
	jQuery(".if-js-closed").removeClass("if-js-closed").addClass("closed");
	postboxes.add_postbox_toggles("slideshow_page_gallery-settings");
});