tinyMCE.addI18n("en.gallery",{
	title : "Insert a slideshow",
	desc : "Insert a slideshow"
});