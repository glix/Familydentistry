<?php if (!empty($message)) : ?>
	<div class="updated fade">
		<p><?php echo $message; ?></p>
	</div>
<?php endif; ?>