<?php if (!empty($paginate -> pagination)) : ?>
	<div class="tablenav-pages">
		<?php echo $paginate -> pagination; ?>
	</div>
<?php endif; ?>