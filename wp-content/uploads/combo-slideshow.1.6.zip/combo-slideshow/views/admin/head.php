<script type="text/javascript">
var CMBSLD_Ajax = "<?php echo CMBSLD_PLUGIN_URL ?>/<?php echo CMBSLD_PLUGIN_NAME ?>-ajax.php";
</script>